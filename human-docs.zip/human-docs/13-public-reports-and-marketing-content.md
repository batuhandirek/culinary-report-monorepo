# Public reports and marketing content

What we can publish for the public from data we already collect, to market the product: to diners (reach and brand), to owners (leads), to press (credibility). Every item says what data it needs, whether that data exists today, the cadence, and the legal or taste caveats.

## Ground rules for anything public

- **Never republish review texts or Google ratings** as our content. Google's reviews are Google's; quoting them in a private report to the venue's owner is one thing, a public page is another. Public content works with **our own counts** (posts, views, creators, shares, rising/falling) and with public venue names and districts.
- **Never show OSM-derived data** (licence).
- **Creators are public figures posting publicly**, but they are people: credit by handle, link to the original, use the platforms' official embeds rather than re-hosting video, and honour a removal request the same day.
- **Venues are businesses**; a factual "most posted about this month" list is fair comment. A "fastest falling" list is not something we publish; negatives stay in the private report.
- **Marketing e-mail needs consent (double opt-in)**; our mail provider (Brevo) is set up for transactional mail today. A newsletter is a product in itself. Gated content (a PDF behind an e-mail form, with a marketing tick box) is the clean way to earn that consent, and it is the only legal way around the cold-e-mail problem the sales doc describes.

## The candidates

| # | Piece | What it shows | Data | Ready today? | Cadence | Effort |
|---|---|---|---|---|---|---|
| 1 | **"Berlin's most talked-about places this month"** (top hits) | Top 10 brands by posts from others, views, number of creators; the five fastest risers; the month's most viewed post (embedded, creator credited); the district with the most posts | Top brands, rising venues, posts: all computed for the report already | **Yes** (September has 433 matched mentions; October 1,111 so far) | Monthly, on the 3rd | Small: a public page per city and month plus share cards. Ticket `monthly-city-highlights-page` |
| 2 | **Food trends, quarterly** | Rising cuisines and dishes by social share, Google search interest (year over year), Google's breakout related queries ("matcha latte berlin"), openings by kind of food | Trend tables, Google Trends rows, related queries | Mostly (openings from 2027) | Quarterly | Medium: ticket `public-food-trends-report` (exists) |
| 3 | **Openings newsletter / page** ("New in Berlin this month") | Places that opened, by district, with the first creators who covered them | Status changes (blind until Jan 2027), "just opened" flag from posts (ticket `opening-flag-in-extraction`), OSM diffs for our own prioritising only | **Not yet**: no opening recorded | Monthly | Small once the flag exists; the newsletter itself needs consent handling |
| 4 | **District guides** ("Where Neukölln eats, according to TikTok") | Per district: the most posted-about places, the dishes named, the creators to follow | Mentions by district, dishes, creators | Yes | Refreshed monthly, evergreen URL | Medium: 12 pages per city, SEO value |
| 5 | **Creator leaderboard** ("Berlin's food creators this month") | Top creators by views on food posts in the city, their most viewed post, which places they covered | Creators table | Yes | Monthly | Small; invite the creators to share it (reach) |
| 6 | **Dish of the month** | The dish whose share jumped most, the places most named for it, the price range from menus (when menus exist) | Trend dishes, menu items (none today) | Partly | Monthly | Small; good Instagram card |
| 7 | **The weekend tables index** | "How booked out Berlin was this weekend": the median booked-out share across every sampled venue, by district | Reservation samples (46 so far; needs weeks of Thursdays) | Not yet | Weekly | Small once samples accumulate; a stat nobody else publishes, press-friendly |
| 8 | **Owner-facing data stories (blog)** | "What keeps Berlin guests from giving 5 stars: 10,000 reviews analysed"; "Only 11 % of September's reviews got an answer"; "Paid creator posts get X× the views of venues' own posts" | Aggregates over reviews and posts (no quotes, no venue names) | Yes | Monthly or as found | Small per post; the blog is built (3 entries); each ends on the sample-report pitch |
| 9 | **Gated benchmark PDF** ("Berlin restaurant social & reviews benchmark") | Medians and percentiles by district and kind of food: posts, views, reply rate, complaint shares, booked-out share | The same aggregates | Yes | Twice a year | Medium: a print page (the PDF pipeline exists) plus a form with a marketing consent tick: **this is the inbound consent engine** |
| 10 | **Instagram account** | Weekly "5 posts Berlin watched this week" (text cards with handle credit and links), monthly top-10 card, trend card, dish card | Items 1, 5, 6 | Yes | Weekly | Small: square and portrait variants of the share cards; the blog's OG-image renderer is the starting point |
| 11 | **Public venue pages** (SEO) | One page per venue: "mentioned in 12 posts this month, by these creators", the dishes named | Everything | Yes | Monthly refresh | Large and sensitive: 5,000 pages, venues may object, no Google figures. A later bet |
| 12 | **Press pitches / data journalism** | "The most TikToked döner in Berlin", "Rain weekends and reservations" | Items 1, 2, 7 | Yes | Opportunistic | None beyond a spreadsheet and a contact list |

## Which to do first

1. **Top hits (1)** and the **Instagram cards (10)**: the data is ready, the page is a day's work, and it is the product's demo in public: every listed venue is a warm lead ("you were #4 in Berlin in September").
2. **Blog data stories (8)**: free, SEO, end on the pitch.
3. **Gated benchmark (9)**: the mechanism that turns readers into consenting e-mail contacts.
4. **Trends (2)** and **district guides (4)** once a second month of comparable data exists.
5. **Openings (3)** and **weekend tables (7)** when their data exists (the extraction flag now, the samples by December).

## Production notes

- Every public piece should be **published by an admin**, never automatically: a list with a wrong match (a namesake, an own-account post counted as word of mouth) in public is worse than a late post. The admin's mention corrections apply before publishing.
- Build public pages on the server-rendered frontend (the blog's pattern: SSR, meta tags, sitemap), one URL per city and month, so they index.
- Share cards: one renderer, three sizes (1200×630 for links, 1080×1080 and 1080×1350 for Instagram).
- Keep a **do-not-list** on the city (like the chain deny list) for venues or creators who asked to be left out.
